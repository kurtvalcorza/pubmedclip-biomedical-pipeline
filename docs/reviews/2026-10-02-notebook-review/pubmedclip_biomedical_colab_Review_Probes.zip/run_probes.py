"""Review probes for tutorials/pubmedclip_biomedical_colab.ipynb (row 71, prefix PMC).

Run with the repository's src/ on sys.path, CUDA_VISIBLE_DEVICES=-1 (CPU only), and the read-only snapshot and
slice cache of a local checkout:
    PMC_REPO=<worktree> PMC_WEIGHTS=<checkout>/weights python run_probes.py
Nothing is written outside a temporary directory. Stand-in subsets are labelled; this is not a notebook run.
"""
from __future__ import annotations

import io
import json
import os
import re
import sys
import tempfile
import time
import zipfile
from pathlib import Path

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
REPO = Path(os.environ["PMC_REPO"])
WEIGHTS = Path(os.environ["PMC_WEIGHTS"])
sys.path.insert(0, str(REPO / "src"))
NB = REPO / "tutorials" / "pubmedclip_biomedical_colab.ipynb"
OUT = Path(__file__).with_name("results.json")
results: dict = {"environment": {}, "probes": {}}


def record(name, payload):
    results["probes"][name] = payload
    OUT.write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")  # write-immediately
    print(name, json.dumps(payload, default=str)[:600])


# ---------------------------------------------------------------- S: static notebook checks
nb = json.loads(NB.read_text(encoding="utf-8"))
cells = nb["cells"]
src = ["".join(c["source"]) for c in cells]
md = "\n".join(s for s, c in zip(src, cells) if c["cell_type"] == "markdown")
code = {i: s for i, (s, c) in enumerate(zip(src, cells)) if c["cell_type"] == "code"}
record("S1_declared_spec", {"metadata": nb["metadata"]["dimer"]["notebook_spec"], "mode": nb["metadata"]["dimer"]["notebook_mode"]})
record("S2_install_in_kernel", {
    "pip_into_kernel": "'-m', 'pip', 'install'" in code[3],
    "restart_instruction": "Restart the runtime, then rerun from the top" in code[3],
    "uv_used": "uv " in code[3] or "uv pip" in code[3],
})
gdl = {k: bool(re.search(p, md, re.I)) for k, p in {
    "how_to_use": r"how to use this notebook", "roadmap": r"roadmap", "glossary": r"glossary",
    "troubleshooting": r"troubleshoot", "predict_prompt": r"\bpredict(ion)? (before|first)|make a prediction",
    "checkpoint_question": r"checkpoint|check your understanding", "sample_answer": r"<details>|sample answer",
    "infrastructure_label": r"infrastructure", "intended_learner": r"intended (learner|audience)|this notebook is for",
}.items()}
record("S3_guided_layer_markers", gdl)
byod = code[19]
record("S4_byod_branch", {
    "imports_google_colab": "from google.colab import files" in byod,
    "location_field": bool(re.search(r"BYOD_(ZIP|PATH)\w*\s*=.*@param", byod)),
    "cancel_guard": "if not uploaded" in byod,
    "fixed_zip_name": "Path('work') / 'byod.zip'" in byod,
})
record("S5_prompt_and_asserts", {
    "ct_prompt_unconditional": "CT_PROMPT = 'An axial abdominal CT slice showing the {label}.'" in code[23],
    "display_names_empty_for_byod": "display_names = {}" in byod,
    "cell23_assert_frozen_beats_majority": "assert frozen_test['t2i_map'] > baseline_majority['t2i_map']" in code[23],
    "cell27_assert_adapted_beats_frozen": "assert adapted_test['t2i_map'] > frozen_test['t2i_map']" in code[27],
    "pipe_rebuilt_before_adapt": "from_pretrained" in code[25] or "from_pretrained" in code[23],
})
record("S6_rerun_instructions", {
    "byod_rerun_from_section4": "re-run from that cell" in src[0],
    "optional_experiments_change_section7": "TRAINABLE_VISION_LAYERS = 4" in src[30],
    "mentions_reset_or_reload": bool(re.search(r"re-?load the (base|pretrained)|reset the model|from the top", src[0] + src[30])),
})
lung = "lung-right" in src[26] or "right lung" in src[26]
record("S7_section8_names_lung_right_ap_drop", {"section8_mentions_right_lung": lung, "section8_text_has_0.34": "0.34" in src[26]})
record("S8_ci_env_var", {"reads_DIMER_NOTEBOOK_CI_PREINSTALLED": "DIMER_NOTEBOOK_CI_PREINSTALLED" in code[3],
                         "documented_in_markdown": "DIMER_NOTEBOOK_CI_PREINSTALLED" in md})

# ---------------------------------------------------------------- B: BYOD loader / split (no model)
from PIL import Image  # noqa: E402

from pubmedclip_pipeline.samples import load_byod_dataset, split_dataset, validate_dataset  # noqa: E402

tmp = Path(tempfile.mkdtemp(prefix="pmc_probe_"))


def png(seed):
    im = Image.new("RGB", (32, 32), (seed * 7 % 256, seed * 13 % 256, seed * 29 % 256))
    im.putpixel((seed % 32, seed // 32 % 32), (255, 255, 255))
    b = io.BytesIO()
    im.save(b, "PNG")
    return b.getvalue()


def make_zip(name, rows, files, header="id,file,label"):
    path = tmp / name
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("labels.csv", header + "\n" + "\n".join(",".join(r) for r in rows) + "\n")
        for member, data in files.items():
            z.writestr(member, data)
    return path


def attempt(fn):
    try:
        out = fn()
        return {"ok": True, "result": out}
    except BaseException as exc:  # noqa: BLE001
        return {"ok": False, "type": type(exc).__name__, "message": str(exc)[:160]}


# stated minimum: "at least eight images over at least two labels"
rows8 = [(f"i{k}", f"i{k}.png", "a" if k < 4 else "b") for k in range(8)]
z8 = make_zip("min8.zip", rows8, {f"i{k}.png": png(k) for k in range(8)})
recs8 = load_byod_dataset(z8)
record("B1_stated_minimum_8_images_2_labels", {
    "validate_dataset": attempt(lambda: validate_dataset(recs8)["n_records"]),
    "split_dataset_seed42": attempt(lambda: {k: len(v) for k, v in split_dataset(recs8, seed=42).items()}),
})
smallest = None
for n in range(4, 20):
    rows = [(f"i{k}", f"i{k}.png", "a" if k < n else "b") for k in range(2 * n)]
    recs = load_byod_dataset(make_zip(f"n{n}.zip", rows, {f"i{k}.png": png(k) for k in range(2 * n)}))
    if attempt(lambda: split_dataset(recs, seed=42))["ok"]:
        smallest = 2 * n
        break
record("B2_smallest_balanced_two_label_set_that_splits", {"images": smallest})
nested = make_zip("nested.zip", [("i0", "images/i0.png", "a")], {"images/i0.png": png(0)})
record("B3_nested_path_in_labels_csv", attempt(lambda: len(load_byod_dataset(nested))))
dup = make_zip("dup.zip", [("i0", "x.png", "a")], {"a/x.png": png(1), "b/x.png": png(2)})
r = load_byod_dataset(dup)
record("B4_duplicate_basenames_collide", {"loaded": len(r), "pixel_of_loaded": r[0]["image"].getpixel((0, 0)),
                                          "a_x_pixel": (7, 13, 29), "b_x_pixel": (14, 26, 58)})
missing = make_zip("missing.zip", [("i0", "nope.png", "a")], {"i0.png": png(0)})
record("B5_missing_member", attempt(lambda: load_byod_dataset(missing)))
notimg = make_zip("notimg.zip", [("i0", "i0.png", "a")], {"i0.png": b"not an image"})
record("B6_non_image_member", attempt(lambda: load_byod_dataset(notimg)))
csvonly = tmp / "byod.zip"
csvonly.write_bytes(b"id,file,label\n")
record("B7_non_zip_upload_saved_as_byod_zip", attempt(lambda: load_byod_dataset(csvonly)))
record("B8_cancelled_upload_next_iter_empty", attempt(lambda: next(iter({}.items()))))
nolabels = tmp / "nolabels.zip"
with zipfile.ZipFile(nolabels, "w") as z:
    z.writestr("i0.png", png(0))
record("B9_zip_without_labels_csv", attempt(lambda: load_byod_dataset(nolabels)))

# ---------------------------------------------------------------- L: near-duplicate scan across roles (660 pinned slices)
import numpy as np  # noqa: E402

from pubmedclip_pipeline.samples import build_sample_dataset, fetch_corpus, read_corpus  # noqa: E402

t0 = time.perf_counter()
corpus = read_corpus(fetch_corpus(cache_dir=WEIGHTS / "organamnist"))
splits = build_sample_dataset(corpus, seed=42)


def vec(rec):
    a = np.asarray(rec["image"].convert("L").resize((32, 32)), dtype=np.float32).ravel()
    a = a - a.mean()
    return a / (np.linalg.norm(a) + 1e-8)


V = {k: np.stack([vec(r) for r in v]) for k, v in splits.items()}
cos_tt = V["test"] @ V["train"].T
cos_te = V["test"] @ V["test"].T
np.fill_diagonal(cos_te, -1)
cos_rr = V["train"] @ V["train"].T
np.fill_diagonal(cos_rr, -1)
nn_test_train = cos_tt.max(axis=1)
nn_test_test = cos_te.max(axis=1)
nn_train_train = cos_rr.max(axis=1)
record("L1_near_duplicate_cosine_32px", {
    "stand_in": "32x32 grey, mean-centred cosine; observation, not a scan-identity check",
    "test_to_nearest_train": {"max": float(nn_test_train.max()), "p50": float(np.median(nn_test_train)), "n_ge_0.98": int((nn_test_train >= 0.98).sum()), "n_ge_0.95": int((nn_test_train >= 0.95).sum())},
    "test_to_nearest_other_test": {"max": float(nn_test_test.max()), "p50": float(np.median(nn_test_test)), "n_ge_0.98": int((nn_test_test >= 0.98).sum())},
    "train_to_nearest_other_train": {"p50": float(np.median(nn_train_train)), "n_ge_0.98": int((nn_train_train >= 0.98).sum())},
    "test_closer_to_train_than_to_any_test": int((nn_test_train > nn_test_test).sum()),
    "n_test": int(len(nn_test_train)),
    "seconds": round(time.perf_counter() - t0, 1),
})

# ---------------------------------------------------------------- R: rerun semantics with the real model (CPU, small subsets)
import torch  # noqa: E402

from pubmedclip_pipeline import PubMedClipPipeline  # noqa: E402
from pubmedclip_pipeline.metrics import majority_baseline  # noqa: E402
from pubmedclip_pipeline.samples import ORGANS  # noqa: E402

results["environment"] = {"python": sys.version.split()[0], "torch": torch.__version__, "cuda_visible": torch.cuda.is_available(), "numpy": np.__version__}
CT_PROMPT = "An axial abdominal CT slice showing the {label}."
names = {k: n for k, (n, _i) in ORGANS.items()}


def take(part, per):
    out, seen = [], {}
    for r in splits[part]:
        if seen.get(r["label"], 0) < per:
            out.append(r)
            seen[r["label"]] = seen.get(r["label"], 0) + 1
    return out


tr, va, te = take("train", 4), take("validation", 2), take("test", 4)
classes = sorted({r["label"] for r in tr})
t0 = time.perf_counter()
pipe = PubMedClipPipeline.from_pretrained(weights_dir=WEIGHTS / "pubmed-clip-vit-base-patch32", device="cpu")
M = ("accuracy", "macro_f1", "t2i_map")
pick = lambda d: {k: round(d[k], 4) for k in M}  # noqa: E731
frozen1 = pipe.evaluate(te, classes=classes, class_names_map=names, prompt_template=CT_PROMPT)
a1 = pipe.adapt(tr, va, epochs=1, lr=5e-5, batch_size=16, trainable_vision_layers=2, prompt_template=CT_PROMPT, class_names_map=names)
adapted1 = pipe.evaluate(te, classes=classes, class_names_map=names, prompt_template=CT_PROMPT)
frozen_rerun = pipe.evaluate(te, classes=classes, class_names_map=names, prompt_template=CT_PROMPT)  # Section 6 re-run
a2 = pipe.adapt(tr, va, epochs=1, lr=5e-5, batch_size=16, trainable_vision_layers=4, prompt_template=CT_PROMPT, class_names_map=names)  # optional experiment: Section 7 re-run
record("R1_rerun_does_not_reset_to_pretrained", {
    "stand_in": "44 train / 22 val / 44 test pinned slices (4/2/4 per organ), 1 epoch, CPU; not the notebook default",
    "section6_frozen_first_run": pick(frozen1),
    "after_adapt_layers2": pick(adapted1),
    "section6_rerun_labelled_frozen": {**pick(frozen_rerun), "adapted_flag": frozen_rerun["adapted"]},
    "rerun_equals_adapted": pick(frozen_rerun) == pick(adapted1),
    "first_adapt_epoch0_note_and_val": {"note": a1["history"][0].get("note"), "val": a1["history"][0]["val"]},
    "second_adapt_epoch0_note_and_val": {"note": a2["history"][0].get("note"), "val": a2["history"][0]["val"]},
    "first_adapt_epoch1_val": a1["history"][1]["val"],
    "second_epoch0_equals_first_selected_state_val": a2["history"][0]["val"] == a1["history"][a1["best_epoch"]]["val"],
    "seconds": round(time.perf_counter() - t0, 1),
})

# ---------------------------------------------------------------- A: BYOD-style data against the Section 6 / Section 8 assertions
t0 = time.perf_counter()
fresh = PubMedClipPipeline.from_pretrained(weights_dir=WEIGHTS / "pubmed-clip-vit-base-patch32", device="cpu")
pool = {lab: [r for r in corpus if r["label"] == lab] for lab in ("liver", "spleen", "kidney-left", "kidney-right")}
cases = {
    "liver_vs_spleen_plain_names": {"liver": "liver", "spleen": "spleen"},
    "kidney_left_vs_right_plain": {"kidney-left": "kidney-left", "kidney-right": "kidney-right"},
    "opaque_codes": {"liver": "class-a", "spleen": "class-b"},
    "annotator_labels": {"kidney-left": "L", "kidney-right": "R"},
}
out = {}
for case, mapping in cases.items():
    recs = []
    for organ, lab in mapping.items():
        for i, r in enumerate(pool[organ][:30]):
            recs.append({"id": f"{lab}-{i}".replace(" ", "_"), "image": r["image"], "label": lab})
    sp = split_dataset(recs, seed=42)
    cls = sorted({r["label"] for r in sp["train"]})
    maj = majority_baseline(sp["train"], sp["test"], cls)
    fr = fresh.evaluate(sp["test"], classes=cls, class_names_map={}, prompt_template=CT_PROMPT)
    passes = fr["t2i_map"] > maj["t2i_map"] and fr["accuracy"] > maj["accuracy"]
    out[case] = {"n_test": len(sp["test"]), "majority": pick(maj), "frozen_ct_prompt": pick(fr), "cell23_assert_passes": passes,
                 "prompt_example": CT_PROMPT.format(label=cls[0])}
record("A1_byod_cell23_assertion", {"stand_in": "30 pinned slices per label, split_dataset(seed=42), fresh pretrained model, CPU", "cases": out,
                                     "seconds": round(time.perf_counter() - t0, 1)})
print("done")
